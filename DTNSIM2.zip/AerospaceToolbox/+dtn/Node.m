classdef (Abstract) Node < handle
    properties
        id (1,1) double
        name (1,1) string
        kind (1,1) string
        lat (1,1) double = 0   % deg
        lon (1,1) double = 0   % deg
        alt_km (1,1) double = 0
        % circular-orbit model
        inc_deg (1,1) double = 0
        meanMotion_degps (1,1) double = 0 % ground track rate
        phase_deg (1,1) double = 0

        % New properties
        range_km (1,1) double = 5000
        capacity_bytes (1,1) double = 1e9 % 1GB default
        bandwidth_bps (1,1) double = 1e6  % 1Mbps default
        % Statistics
        dropped_bytes (1,1) double = 0
        dropped_count (1,1) double = 0
        created_count (1,1) double = 0
        relayed_count (1,1) double = 0
        contact_count (1,1) double = 0
        dupe_count (1,1) double = 0
        error_count (1,1) double = 0
        storage_used_bytes (1,1) double = 0

        % Helper for FIFO/Priority
        arrival_times containers.Map

        messages
        pos_ecef (1,3) double = [0 0 0] % ECEF position for contact checks
    end
    methods
        function self = Node(id,name,kind)
            self.id = id; self.name = string(name); self.kind = string(kind);
            self.messages = containers.Map('KeyType','double','ValueType','any');
            self.arrival_times = containers.Map('KeyType','double','ValueType','double');
        end
        function [lat,lon,alt_km] = position(self)
            lat = self.lat; lon = self.lon; alt_km = self.alt_km;
        end
        function s = speed_kms(self)
            % approximate tangential speed for circular motion
            Re = 6371;  % km
            r = Re + self.alt_km;
            % convert groundtrack rate to radians/sec
            w = abs(self.meanMotion_degps)*pi/180;
            s = w * r * cosd(self.inc_deg); % crude, good enough for UI table
            if self.kind == "Ground", s = 0; end
        end
        function txt = pathSummary(self)
            if self.kind == "Ground"
                txt = sprintf('Fixed @ (%.1f,%.1f)',self.lat,self.lon);
            elseif self.kind == "GEO"
                txt = sprintf('Equatorial GEO @ lon %.1f°', self.lon);
            else
                txt = sprintf('inc %.0f°, Ωdot %.2f°/s', self.inc_deg, self.meanMotion_degps);
            end
        end
        function step(self, dt)
            if self.kind ~= "Ground"
                % very simple "circular" ground-track update
                self.phase_deg = self.phase_deg + self.meanMotion_degps*dt;
                lon = self.lon + self.meanMotion_degps*dt;
                lon = wrapTo180(lon);
                self.lon = lon;
                % lat oscillation by inclination
                self.lat = sind(self.inc_deg) * sind(self.phase_deg);
            end

            % Update ECEF position
            self.updateECEF();
        end

        function updateECEF(self)
            % Simple conversion: LLA to ECEF
            Re = 6371;
            phi = deg2rad(self.lat);
            lam = deg2rad(self.lon);
            r = Re + self.alt_km;
            x = r * cos(phi) * cos(lam);
            y = r * cos(phi) * sin(lam);
            z = r * sin(phi);
            self.pos_ecef = [x y z];
        end

        function addMessage(self, msg)
            % Check if we already have it
            if self.messages.isKey(msg.id)
                self.dupe_count = self.dupe_count + 1;
                return;
            end

            % Evict oldest if needed
            while self.storage_used_bytes + msg.sizeB > self.capacity_bytes
                if self.messages.Count == 0
                    % Message itself is too big for empty buffer?
                    warning('Node %s: Message %d too big (%d > %d)', self.name, msg.id, msg.sizeB, self.capacity_bytes);
                    self.dropped_count = self.dropped_count + 1;
                    self.dropped_bytes = self.dropped_bytes + msg.sizeB;
                    return;
                end

                % Find oldest
                keys = self.arrival_times.keys;
                minT = inf; oldestId = -1;
                for k=1:numel(keys)
                    mid = keys{k};
                    t = self.arrival_times(mid);
                    if t < minT
                        minT = t; oldestId = mid;
                    end
                end

                if oldestId ~= -1
                    % Drop it
                    oldMsg = self.messages(oldestId);
                    self.removeMessage(oldestId);
                    self.dropped_count = self.dropped_count + 1;
                    self.dropped_bytes = self.dropped_bytes + oldMsg.sizeB;
                    % fprintf('Node %s dropped msg %d (buffer full)\n', self.name, oldestId);
                else
                    break; % Should not happen
                end
            end

            self.messages(msg.id) = msg;
            self.arrival_times(msg.id) = now; % Use current wall time or sim time if passed?
            % 'now' is okay for FIFO ordering of arrival
            self.storage_used_bytes = self.storage_used_bytes + msg.sizeB;
        end

        function removeMessage(self, msgId)
            if self.messages.isKey(msgId)
                msg = self.messages(msgId);
                self.storage_used_bytes = self.storage_used_bytes - msg.sizeB;
                self.messages.remove(msgId);
                if self.arrival_times.isKey(msgId)
                    self.arrival_times.remove(msgId);
                end
            end
        end
    end
end
