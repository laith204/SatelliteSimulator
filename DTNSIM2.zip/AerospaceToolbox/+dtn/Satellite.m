classdef (Abstract) Satellite < dtn.Node
    %CIRCULAR ORBIT satellite around Earth center, simple 2-body model.
    properties
        Re_km (1,1) double = 6371
        mu (1,1) double = 398600 % km^3/s^2
        alt_km (1,1) double
        inc_deg (1,1) double
        raan_deg (1,1) double
        argp_deg (1,1) double = 0
        M0_deg (1,1) double = 0 % mean anomaly at t0
        t0 (1,1) double = 0
        omega_rad (1,1) double % mean motion
        color (1,3) double = [1 0 0]
    end
    methods
        function self = Satellite(id, name, type, alt_km, inc_deg, raan_deg, color)
            self@dtn.Node(id, name, type);
            self.alt_km = alt_km; self.inc_deg = inc_deg; self.raan_deg = raan_deg;
            if nargin>=7, self.color = color; end
            a = self.Re_km + alt_km;
            self.omega_rad = sqrt(self.mu/a^3);
        end
        function step(self, t, dt)
            % Simple circular orbit propagation using mean anomaly
            M = self.M0_deg*pi/180 + self.omega_rad*(t - self.t0);
            % For circular, E = M, true anomaly = M
            nu = M;
            a = self.Re_km + self.alt_km;
            r_pf = [a*cos(nu), a*sin(nu), 0]; % perifocal
            % Rotation matrices
            inc = deg2rad(self.inc_deg);
            RAAN = deg2rad(self.raan_deg);
            argp = deg2rad(self.argp_deg);
            R3_W = [cos(RAAN) -sin(RAAN) 0; sin(RAAN) cos(RAAN) 0; 0 0 1];
            R1_i = [1 0 0; 0 cos(inc) -sin(inc); 0 sin(inc) cos(inc)];
            R3_w = [cos(argp) -sin(argp) 0; sin(argp) cos(argp) 0; 0 0 1];
            Q = R3_W*R1_i*R3_w;
            self.pos_ecef = (Q * r_pf.').';
        end
    end
end
