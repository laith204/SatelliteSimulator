classdef LEO < dtn.Node
    methods
        function self = LEO(id,name,alt_km,inc_deg,lon0)
            self@dtn.Node(id,name,'LEO');
            self.inc_deg = inc_deg;
            self.alt_km  = alt_km;
            self.lon     = lon0;
            self.lat     = 0;
            self.phase_deg = 0; % Start at equator crossing (Ascending Node)

            % Calculate Mean Motion (Physics-based)
            mu = 398600; % Earth param km^3/s^2
            Re = 6371;
            a = Re + alt_km;
            n_rad = sqrt(mu / a^3);
            n_deg = n_rad * (180/pi);

            % Earth rotation rate (approx)
            w_earth = 360 / 86164;

            % Ground track rate (approx)
            self.meanMotion_degps = n_deg - w_earth;
            self.updateECEF();
        end
    end
end
