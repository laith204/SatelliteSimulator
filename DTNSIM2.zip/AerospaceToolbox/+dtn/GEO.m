classdef GEO < dtn.Node
    methods
        function self = GEO(id,name,alt_km,lon0)
            self@dtn.Node(id,name,'GEO');
            self.inc_deg = 0;
            self.alt_km  = alt_km;        % GEO altitude
            self.lon     = lon0;          % fixed over equator
            self.lat     = 0;
            self.meanMotion_degps = 0;    % geostationary in this toy model
            self.updateECEF();
        end

        function txt = pathSummary(self)
            txt = sprintf('Geostationary @ lon %.1f°', self.lon);
        end
    end
end
