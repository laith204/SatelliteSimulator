classdef Prophet < handle
    properties
        P_encounter (1,1) double = 0.75
        P_aging (1,1) double = 0.98
        P_transitive (1,1) double = 0.5

        % Matrix of Probabilities P(u,v)
        % Rows are source nodes, Cols are target nodes.
        % P(u, v) is probability node u predicts it can reach node v.
        P double = []
    end
    methods
        function self = Prophet()
            self.P = zeros(10,10); % Start small, auto-expand
        end

        function msg = initMessage(self, msg)
            % No specific init needed for Prophet
        end

        function decay(self)
            % Aging: P = P * P_aging
            % Ensure we don't reduce empty/unused parts needlessly if huge,
            % but for matrix operations, simple multiplication is fast.
            self.P = self.P * self.P_aging;
        end

        function p = getProb(self, u, v)
            [R, C] = size(self.P);
            if u > R || v > C
                p = 0;
            else
                p = self.P(u, v);
            end
        end

        function ensureSize(self, maxId)
            [R, C] = size(self.P);
            if maxId > R
                newSize = max(maxId, R*2); % Double strictly to amortize
                % Pad with zeros
                newP = zeros(newSize, newSize);
                newP(1:R, 1:C) = self.P;
                self.P = newP;
            end
        end

        function onContact(self, sim, a, b, t)
            u = a.id; v = b.id;
            self.ensureSize(max(u, v));

            % 1. Update direct delivery probabilities (Encounter)
            p_uv = self.P(u, v);
            p_uv = p_uv + (1 - p_uv) * self.P_encounter;
            self.P(u, v) = p_uv;
            self.P(v, u) = p_uv;

            % 2. Transitive Properties (Beta update)
            % For every node k known by b, update a's metric to k
            % P(a,k) = P(a,k) + (1 - P(a,k)) * P_transitive * P(b,k)
            % Only indices that matter are 1:size(P,1), strictly speaking we simulate all.
            % But we should skip 'u' and 'v' themselves.

            % Get current rows
            rowU = self.P(u, :);
            rowV = self.P(v, :);

            % Vectorized Update
            % NewRowU = RowU + (1-RowU) * beta * RowV
            beta = self.P_transitive;

            updateU = rowU + (1 - rowU) .* beta .* rowV;
            updateV = rowV + (1 - rowV) .* beta .* rowU;

            % Apply masking: Don't update index u or v within the row logic
            % (Original code: if k == a.id || k == b.id, continue)
            % We just revert those specific indices or construct a mask
            mask = true(1, size(self.P, 2));
            mask(u) = false;
            mask(v) = false;

            self.P(u, mask) = updateU(mask);
            self.P(v, mask) = updateV(mask);

            % 3. Exchange messages
            self.transfer(sim, a, b);
            self.transfer(sim, b, a);
        end

        function transfer(self, sim, src, dst)
            if isempty(src.messages), return; end

            keys = src.messages.keys;

            % Pre-fetch probability rows to avoid repeated calls/checks
            % (Though in this architecture, src/dst are objects, so we just use IDs)
            % The matrix self.P is already up to date from onContact.

            p_dst_vec = self.P(dst.id, :);
            p_src_vec = self.P(src.id, :);

            for i = 1:numel(keys)
                msgId = keys{i};
                msg = src.messages(msgId);

                if msg.dst == dst.id
                    % Direct Delivery
                    msg.hops = msg.hops + 1;
                    msg.bytesTransmitted = msg.bytesTransmitted + msg.sizeB;
                    msg.path = [msg.path dst.id];
                    sim.deliverIfArrived(msg, dst, sim.t);
                    continue;
                end

                % Loop Prevention
                if ismember(dst.id, msg.path)
                    continue;
                end

                % Forward Logic: P(dst, dest) > P(src, dest)
                if ~dst.messages.isKey(msgId)
                    % Use vectorized lookup if safe, else scalar
                    destId = msg.dst;

                    % Check bounds
                    if destId > size(self.P, 2)
                        p_dst_dest = 0;
                        p_src_dest = 0;
                    else
                        p_dst_dest = p_dst_vec(destId);
                        p_src_dest = p_src_vec(destId);
                    end

                    if p_dst_dest >= p_src_dest
                        if dst.storage_used_bytes + msg.sizeB <= dst.capacity_bytes
                            % Copy
                            msg.hops = msg.hops + 1;
                            msg.bytesTransmitted = msg.bytesTransmitted + msg.sizeB;
                            msg.path = [msg.path dst.id];
                            dst.addMessage(msg);
                            sim.logTransfer(msg, src, dst, sim.t);
                        end
                    end
                end
            end
        end
    end
end
