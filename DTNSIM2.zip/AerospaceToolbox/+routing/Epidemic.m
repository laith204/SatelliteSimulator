classdef Epidemic < handle
    % Epidemic Routing (formerly CGRLite)
    % Floods messages to every node encountered.
    methods
        function onContact(~, sim, a, b, t)
            % Simple Epidemic/Flood
            transfer(sim, a, b);
            transfer(sim, b, a);
        end
    end
end

function transfer(sim, src, dst)
if isempty(src.messages), return; end

% Range check handled by Simulator (Handshake implies connection)
keys = src.messages.keys;
for i = 1:numel(keys)
    msgId = keys{i};
    msg = src.messages(msgId);

    if msg.dst == dst.id
        % Update stats before delivery
        msg.hops = msg.hops + 1;
        msg.bytesTransmitted = msg.bytesTransmitted + msg.sizeB;
        msg.path = [msg.path dst.id];

        sim.deliverIfArrived(msg, dst, sim.t);
        continue;
    end

    if ~dst.messages.isKey(msgId)
        if dst.storage_used_bytes + msg.sizeB <= dst.capacity_bytes
            % Update stats on copy
            msg.hops = msg.hops + 1;
            msg.bytesTransmitted = msg.bytesTransmitted + msg.sizeB;
            msg.path = [msg.path dst.id];

            dst.addMessage(msg);
            sim.logTransfer(msg, src, dst, sim.t);
        end
    end
end
end
