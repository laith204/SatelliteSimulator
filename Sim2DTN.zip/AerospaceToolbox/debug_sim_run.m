try
    fprintf('Starting Debug Run...\n');

    % 1. Setup Config
    config = struct();
    config.routing = 'Spray and Wait';
    config.duration = 1; % 1 hour

    % Nodes
    n1 = struct('type', 'Ground', 'name', 'Ground1', 'buffer', 100, 'bandwidth', 10, 'range', 7500);
    n2 = struct('type', 'LEO', 'name', 'LEO1', 'buffer', 100, 'bandwidth', 10, 'range', 7500);
    config.nodes = {n1, n2};

    % Messages
    m1 = struct('src', 'Ground1', 'dst', 'LEO1', 'sizeKB', 10, 'pktKB', 1);
    config.messages = {m1};

    % 2. Initialize Engine
    fprintf('Initializing Engine...\n');
    import AerospaceToolbox.SimEngine
    engine = SimEngine(config);

    % 3. Run
    fprintf('Running Simulation...\n');
    engine.run();

    fprintf('Debug Run Completed Successfully.\n');
catch e
    fprintf('ERROR CAUGHT:\n');
    fprintf('%s\n', getReport(e));
end
