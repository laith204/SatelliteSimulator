classdef StatsWindow < handle
    properties
        Fig
        Grid
        Stats
    end

    methods
        function self = StatsWindow(stats)
            self.Stats = stats;
            self.createUI();
        end

        function createUI(self)
            self.Fig = uifigure('Name', 'Simulation Statistics', 'Position', [100 100 1000 700]);
            self.Grid = uigridlayout(self.Fig, [2, 2]);
            self.Grid.RowHeight = {'1x', '1x'};
            self.Grid.ColumnWidth = {'2x', '1x'};

            % --- Top Row: Node Statistics ---
            pnlNodes = uipanel(self.Grid, 'Title', 'Node Statistics');
            pnlNodes.Layout.Row = 1;
            pnlNodes.Layout.Column = [1 2];
            glNodes = uigridlayout(pnlNodes, [1, 1]);

            if isempty(self.Stats.nodes)
                nodeData = table({}, [], [], [], [], [], [], [], ...
                    'VariableNames', {'Name', 'Dropped_Bytes', 'Dropped_Pkts', 'Buffer_Used', 'Custody', 'Discovery', 'Dupes', 'Errors'});
            else
                nodeData = struct2table(self.Stats.nodes);
                nodeData.Properties.VariableNames = {'Name', 'Dropped_Bytes', 'Dropped_Pkts', 'Buffer_Used', 'Custody', 'Discovery', 'Dupes', 'Errors'};
            end
            uitable(glNodes, 'Data', nodeData, 'ColumnSortable', true);

            % --- Bottom Left: Event Log (Tabbed) ---
            % Create TabGroup
            tg = uitabgroup(self.Grid);
            tg.Layout.Row = 2;
            tg.Layout.Column = 1;

            % Prepare Data
            if isfield(self.Stats, 'events') && ~isempty(self.Stats.events)
                fullLogData = struct2table(self.Stats.events);
                % Filter for Primary Tab (Created, Custody, Delivered)
                % Filter out 'Handshake'
                isRelevant = ismember(fullLogData.Type, ["Created", "Custody", "Delivered"]);
                relevantLogData = fullLogData(isRelevant, :);
            else
                fullLogData = table('Size', [0 3], 'VariableTypes', {'double', 'string', 'string'}, 'VariableNames', {'Time', 'Type', 'Details'});
                relevantLogData = fullLogData;
            end

            % Tab 1: Primary Log
            tab1 = uitab(tg, 'Title', 'Primary Log (Transfers)');
            glTab1 = uigridlayout(tab1, [1, 1]);
            uitable(glTab1, 'Data', relevantLogData, 'ColumnSortable', true, 'ColumnWidth', {60, 100, 'auto'});

            % Tab 2: All Events
            tab2 = uitab(tg, 'Title', 'All Events (Debug)');
            glTab2 = uigridlayout(tab2, [1, 1]);
            uitable(glTab2, 'Data', fullLogData, 'ColumnSortable', true, 'ColumnWidth', {60, 100, 'auto'});

            % --- Bottom Right: Overall Statistics ---
            pnlOverall = uipanel(self.Grid, 'Title', 'Overall Statistics');
            pnlOverall.Layout.Row = 2;
            pnlOverall.Layout.Column = 2;
            glOverall = uigridlayout(pnlOverall, [8, 2]);
            glOverall.ColumnWidth = {'1x', '1x'};

            self.addStatRow(glOverall, 'Packets Created:', self.Stats.total_created);
            self.addStatRow(glOverall, 'Packets Delivered:', self.Stats.total_delivered);
            self.addStatRow(glOverall, 'PDR (%):', sprintf('%.2f', self.Stats.pdr));
            self.addStatRow(glOverall, 'Data Dropped (Bytes):', self.Stats.total_dropped_B);
            self.addStatRow(glOverall, 'Data Dropped (Pkts):', self.Stats.total_dropped_P);
            self.addStatRow(glOverall, 'Avg Latency (s):', sprintf('%.2f', self.Stats.avg_latency));
            self.addStatRow(glOverall, 'Avg Throughput (B/s):', sprintf('%.2f', self.Stats.avg_throughput));
            self.addStatRow(glOverall, 'Routing Algorithm:', self.Stats.routing_algo);
        end

        function addStatRow(~, parent, label, value)
            uilabel(parent, 'Text', label, 'FontWeight', 'bold', 'HorizontalAlignment', 'right');
            if isnumeric(value)
                valStr = num2str(value);
            else
                valStr = string(value);
            end
            uilabel(parent, 'Text', valStr, 'HorizontalAlignment', 'left');
        end
    end
end
