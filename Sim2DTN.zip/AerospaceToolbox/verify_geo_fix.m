
% Verify GEO Fix
clc;
import AerospaceToolbox.Simulator

diary('verify_log.txt');
try
    fprintf('1. Testing GEO Position Update...\n');
    % Create GEO node
    % id, name, alt, raan
    geo = dtn.GEO(1, 'GEO1', 35786, 0);

    % Initial pos (should be 0 before step, or something else if ctor sets it?)
    % Node constructor initializes pos_ecef to [0 0 0]
    p0 = geo.pos_ecef;
    fprintf('Initial Pos: [%.2f, %.2f, %.2f]\n', p0);

    if isequal(p0, [0 0 0])
        fprintf('  Confirmed: Initial position is [0,0,0]\n');
    end

    % Step forward
    dt = 60; % 1 minute
    geo.step(dt);

    p1 = geo.pos_ecef;
    fprintf('Post-Step Pos: [%.2f, %.2f, %.2f]\n', p1);

    dist = norm(p1);
    fprintf('Distance from center: %.2f km\n', dist);

    expectedDist = 6371 + 35786;
    if abs(dist - expectedDist) < 100
        fprintf('  SUCCESS: Position updated correctly (Dist ~ %.2f km)\n', dist);
    else
        error('  FAILURE: Position did not update correctly (Dist ~ %.2f km, Expected %.2f)\n', dist, expectedDist);
    end

    fprintf('\n2. Testing Line of Sight...\n');
    sim = Simulator();
    % Add Ground Node at 0,0
    gId = sim.addGround('Ground1', 0, 0);
    gNode = sim.getNodeById(gId);

    % Add GEO Node at 0 deg longitude
    geoId = sim.addGEO('GEO1', 35786, 0);
    geoNode = sim.getNodeById(geoId);

    % Step to update positions
    sim.step();

    % Check access
    los = sim.lineOfSight(gNode, geoNode);
    range = sim.inRange(gNode, geoNode);

    fprintf('Line of Sight: %d\n', los);
    fprintf('In Range: %d\n', range);

    if los && range
        fprintf('  SUCCESS: GEO node is reachable from Ground.\n');
    else
        fprintf('  FAILURE: Reachability check failed (LOS: %d, Range: %d)\n', los, range);
        if ~range
            fprintf('    Debug: Dist = %.2f km, Ground Range = %.2f km, GEO Range = %.2f km\n', ...
                norm(gNode.pos_ecef - geoNode.pos_ecef), gNode.range_km, geoNode.range_km);
        end
    end

catch e
    fprintf('\nEXCEPTION: %s\n', e.message);
    fprintf('%s\n', getReport(e));
end
diary off;
