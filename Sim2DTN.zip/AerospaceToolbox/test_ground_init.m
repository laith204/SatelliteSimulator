
% Test Ground Node Initialization
clc;
import dtn.GroundNode
import dtn.Node

fprintf('Testing GroundNode Initialization...\n');

% Create a ground node
g = GroundNode(1, 'G1', 0, 0);

% Check initial position
pos = g.pos_ecef;
fprintf('Initial Pos ECEF: [%.2f, %.2f, %.2f]\n', pos);
dist = norm(pos);
fprintf('Initial Distance from Center: %.2f km\n', dist);

if dist < 6371
    fprintf('FAIL: Node initialized below Earth Radius (6371 km)\n');
else
    fprintf('PASS: Node initialized at/above Earth Radius\n');
end

% Check if stepping fixes it
fprintf('Stepping node (dt=1)...\n');
g.step(1);
pos_after = g.pos_ecef;
dist_after = norm(pos_after);
fprintf('Post-Step Distance: %.2f km\n', dist_after);

if dist_after < 6371
    fprintf('FAIL: Node ended up below Earth Radius after step\n');
else
    fprintf('PASS: Node is valid after step\n');
end
