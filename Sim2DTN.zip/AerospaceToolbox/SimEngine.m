classdef SimEngine < handle
    properties
        Config
        Sim
        Scenario
        Satellites = {}
        NodeMap % Map from Sim ID to Scenario Object

        StartTime
        StopTime
        SampleTime = 50; % seconds
    end

    methods
        function self = SimEngine(config)
            self.Config = config;
            self.StartTime = datetime('now');
            if isfield(config, 'duration')
                self.StopTime = self.StartTime + hours(config.duration);
            else
                self.StopTime = self.StartTime + hours(2);
            end
            self.NodeMap = containers.Map('KeyType', 'double', 'ValueType', 'any');
        end

        function run(self)
            import dtn.*

            % 1. Initialize Simulator
            self.Sim = Simulator();
            self.Sim.setRouting(self.Config.routing);
            self.Sim.dt = self.SampleTime;

            % 2. Initialize Scenario
            self.Scenario = satelliteScenario(self.StartTime, self.StopTime, self.SampleTime);

            % 3. Add Nodes
            self.addNodes();

            % 4. Add Messages
            self.addMessages();

            % 5. Run Simulation Logic
            fprintf('Running Simulation Logic...\n');
            self.runLogic();

            % 6. Visualize
            fprintf('Preparing Visualization...\n');
            self.visualize();

            % 7. Show Stats
            StatsWindow(self.Sim.getStats());
        end

        function addNodes(self)
            % Random seed
            rng('shuffle');

            for i=1:numel(self.Config.nodes)
                nConf = self.Config.nodes{i};
                simId = -1;
                scObj = [];

                switch nConf.type
                    case 'LEO'
                        % Random LEO: Alt 600-1200km (Thinner range)
                        alt = 600e3 + rand()*600e3;
                        inc = rand()*180;
                        raan = rand()*360;
                        simId = self.Sim.addLEO(nConf.name, alt/1000, inc, raan);

                        % Add to Scenario
                        sma = 6378137 + alt;
                        scObj = satellite(self.Scenario, sma, 0, inc, raan, 0, rand()*360, 'Name', nConf.name);
                        scObj.MarkerColor = [0 1 1]; % Cyan

                    case 'MEO'
                        % Random MEO: Alt 10000-20000km (Thinner range)
                        alt = 10000e3 + rand()*10000e3;
                        inc = rand()*180;
                        raan = rand()*360;
                        simId = self.Sim.addMEO(nConf.name, alt/1000, inc, raan);

                        sma = 6378137 + alt;
                        scObj = satellite(self.Scenario, sma, 0, inc, raan, 0, rand()*360, 'Name', nConf.name);
                        scObj.MarkerColor = [1 1 0]; % Yellow

                    case 'GEO'
                        % GEO: Alt ~35786km, Inc ~0
                        alt = 35786e3;
                        raan = rand()*360;
                        simId = self.Sim.addGEO(nConf.name, alt/1000, raan);

                        sma = 6378137 + alt;
                        scObj = satellite(self.Scenario, sma, 0, 0, raan, 0, rand()*360, 'Name', nConf.name);
                        scObj.MarkerColor = [1 0 0]; % Red

                    case 'Ground'
                        % Random Ground: Lat -90 to 90, Lon -180 to 180
                        lat = -90 + rand()*180;
                        lon = -180 + rand()*360;
                        simId = self.Sim.addGround(nConf.name, lat, lon);

                        scObj = groundStation(self.Scenario, lat, lon, 'Name', nConf.name);
                        scObj.MarkerColor = [0 1 0]; % Green
                end

                % Set Buffer/BW if applicable
                node = self.Sim.getNodeById(simId);
                if isprop(node, 'MAX_BUFFER')
                    node.MAX_BUFFER = nConf.buffer * 1e6; % MB to Bytes
                end

                if isfield(nConf, 'range') && isprop(node, 'range_km')
                    node.range_km = nConf.range;
                else
                    % Fallback defaults if not in config
                    if nConf.type == "LEO" || nConf.type == "Ground"
                        node.range_km = 7500; % Increased from 5000
                    elseif nConf.type == "MEO"
                        node.range_km = 25000;
                    elseif nConf.type == "GEO"
                        node.range_km = 50000;
                    end
                end
                % Bandwidth is usually link property, but we can store it on node for now or use default

                self.NodeMap(simId) = scObj;
                self.Satellites{end+1} = scObj;
            end

            % Add default 'Range' access between all pairs (Dotted Lines)
            fprintf('Adding range visualization (dotted lines)...\n');
            nodes = self.Satellites;
            for i=1:numel(nodes)-1
                for j=i+1:numel(nodes)
                    % Create access
                    ac = access(nodes{i}, nodes{j});
                    ac.LineColor = [0.7 0.7 0.7]; % Light Gray for Range
                    ac.LineWidth = 1;
                end
            end
        end

        function addMessages(self)
            for i=1:numel(self.Config.messages)
                mConf = self.Config.messages{i};

                % Find IDs
                srcId = self.findNodeId(mConf.src);
                dstId = self.findNodeId(mConf.dst);

                if srcId ~= -1 && dstId ~= -1
                    self.Sim.createMessage(srcId, dstId, mConf.sizeKB*1024, mConf.pktKB*1024);
                end
            end
        end

        function id = findNodeId(self, name)
            id = -1;
            for k=1:numel(self.Sim.nodes)
                if strcmp(self.Sim.nodes{k}.name, name)
                    id = self.Sim.nodes{k}.id;
                    return;
                end
            end
        end

        function runLogic(self)
            % Pre-calculate positions from Scenario to feed Simulator
            numSteps = floor(seconds(self.StopTime - self.StartTime) / self.SampleTime);
            fprintf('Simulating %d steps (Duration: %s, dt: %d s)\n', numSteps, string(self.StopTime - self.StartTime), self.SampleTime);

            % Step-by-step logic (Fast Internal Propagation)
            for t = 1:numSteps
                % 1. Advance Simulator (updates positions internally)
                self.Sim.step();

                % Progress print every 10%
                if mod(t, max(1, floor(numSteps/10))) == 0
                    fprintf('Progress: %.0f%%\n', (t/numSteps)*100);
                end
            end
        end

        function visualize(self)
            % Add Access links for all successful contacts or hops
            % We can visualize the 'path' of delivered messages

            v = satelliteScenarioViewer(self.Scenario);

            % Highlight paths
            % Highlight transfers with message colors
            transfers = self.Sim.history.transfers;
            if isempty(transfers)
                fprintf('No transfers recorded to visualize.\n');
            else
                fprintf('Visualizing %d transfers...\n', numel(transfers));
                for i=1:numel(transfers)
                    tr = transfers(i);

                    % Get Scenario Objects
                    if self.NodeMap.isKey(tr.src) && self.NodeMap.isKey(tr.dst)
                        uObj = self.NodeMap(tr.src);
                        vObj = self.NodeMap(tr.dst);

                        % Create access
                        % We create a new access object for each transfer to represent that specific message flow
                        % Note: This might create many overlapping lines if multiple messages flow over the same link
                        ac = access(uObj, vObj);
                        ac.LineColor = tr.color;
                        ac.LineWidth = 3;   % Thicker for Transfer
                    end
                end
            end

            % Play
            play(self.Scenario);
        end
    end
end
