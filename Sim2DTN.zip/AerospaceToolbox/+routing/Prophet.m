classdef Prophet < handle
    properties
        P_encounter (1,1) double = 0.75
        P_aging (1,1) double = 0.98
        P_transitive (1,1) double = 0.5

        % Map of NodeID -> Map(NodeID -> Probability)
        probs
    end
    methods
        function self = Prophet()
            self.probs = containers.Map('KeyType','double','ValueType','any');
        end

        function msg = initMessage(self, msg)
            % No specific init needed for Prophet
        end

        function decay(self)
            nodeIds = self.probs.keys;
            for i=1:numel(nodeIds)
                u = nodeIds{i};
                row = self.probs(u);
                targets = row.keys;
                for j=1:numel(targets)
                    v = targets{j};
                    row(v) = row(v) * self.P_aging;
                end
            end
        end

        function p = getProb(self, u, v)
            if ~self.probs.isKey(u)
                self.probs(u) = containers.Map('KeyType','double','ValueType','double');
            end
            row = self.probs(u);
            if ~row.isKey(v), row(v) = 0; end
            p = row(v);
        end

        function setProb(self, u, v, p)
            if ~self.probs.isKey(u)
                self.probs(u) = containers.Map('KeyType','double','ValueType','double');
            end
            row = self.probs(u);
            row(v) = p;
        end

        function onContact(self, sim, a, b, t)
            % Update delivery probabilities
            p_ab = self.getProb(a.id, b.id);
            p_ab = p_ab + (1 - p_ab) * self.P_encounter;
            self.setProb(a.id, b.id, p_ab);
            self.setProb(b.id, a.id, p_ab);

            % Transitive Properties (Beta update)
            % For every node k known by b, update a's metric to k
            % P(a,k) = P(a,k) + (1 - P(a,k)) * P_transitive * P(b,k)

            % Union of known keys
            keysA = cell2mat(self.probs(a.id).keys);
            keysB = cell2mat(self.probs(b.id).keys);
            allKeys = unique([keysA, keysB]);

            for i=1:numel(allKeys)
                k = allKeys(i);
                if k == a.id || k == b.id, continue; end

                p_ak = self.getProb(a.id, k);
                p_bk = self.getProb(b.id, k);

                % Update A using B's info
                p_ak_new = p_ak + (1 - p_ak) * self.P_transitive * p_bk;
                self.setProb(a.id, k, p_ak_new);

                % Update B using A's info
                p_bk_new = p_bk + (1 - p_bk) * self.P_transitive * p_ak;
                self.setProb(b.id, k, p_bk_new);
            end

            % Exchange messages
            self.transfer(sim, a, b);
            self.transfer(sim, b, a);
        end

        function transfer(self, sim, src, dst)
            if isempty(src.messages), return; end

            % Range check handled by Simulator (Handshake implies connection)

            keys = src.messages.keys;
            for i = 1:numel(keys)
                msgId = keys{i};
                msg = src.messages(msgId);

                if msg.dst == dst.id
                    % Update stats before delivery
                    msg.hops = msg.hops + 1;
                    msg.bytesTransmitted = msg.bytesTransmitted + msg.sizeB;
                    msg.path = [msg.path dst.id];

                    sim.deliverIfArrived(msg, dst, sim.t);
                    continue; % Continue to next message instead of returning
                end

                % Loop Prevention: Don't send back to someone who already had it
                if ismember(dst.id, msg.path)
                    continue;
                end

                if ~dst.messages.isKey(msgId)
                    % Forward if P(dst, dest) > P(src, dest)
                    p_src_dest = self.getProb(src.id, msg.dst);
                    p_dst_dest = self.getProb(dst.id, msg.dst);

                    if p_dst_dest >= p_src_dest
                        if dst.storage_used_bytes + msg.sizeB <= dst.capacity_bytes
                            % Update stats on copy
                            msg.hops = msg.hops + 1;
                            msg.bytesTransmitted = msg.bytesTransmitted + msg.sizeB;
                            msg.path = [msg.path dst.id];

                            dst.addMessage(msg);
                            sim.logTransfer(msg, src, dst, sim.t);
                        end
                    end
                end
            end
        end
    end
end

