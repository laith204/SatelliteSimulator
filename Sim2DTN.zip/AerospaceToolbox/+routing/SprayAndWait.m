classdef SprayAndWait < handle
    properties
        L (1,1) double = 4 % Max copies
    end
    methods
        function self = SprayAndWait(L)
            if nargin>=1, self.L = L; end
        end

        function msg = initMessage(self, msg)
            % Initialize message metadata for Spray and Wait
            msg.meta.copies = self.L;
        end

        function onContact(self, sim, a, b, t)
            % Exchange messages between node a and node b
            self.transfer(sim, a, b, t);
            self.transfer(sim, b, a, t);
        end

        function transfer(~, sim, src, dst, t)
            % Try to transfer messages from src to dst
            if isempty(src.messages), return; end

            % Range check handled by Simulator (Handshake implies connection)

            keys = src.messages.keys;
            for i = 1:numel(keys)
                msgId = keys{i};
                msg = src.messages(msgId);

                % 1. If dst is destination, deliver!
                if msg.dst == dst.id
                    % Update stats before delivery
                    msg.hops = msg.hops + 1;
                    msg.bytesTransmitted = msg.bytesTransmitted + msg.sizeB;
                    msg.path = [msg.path dst.id];

                    sim.deliverIfArrived(msg, dst, t);
                    % Remove from network?
                    % deliverIfArrived removes copies if successful?
                    % Simulator.deliverIfArrived removes copies from ALL nodes.
                    % Message consumed
                    continue;
                end

                % 2. If not destination, check if we can spray
                if ~dst.messages.isKey(msgId)
                    copies = 1;
                    if isfield(msg.meta, 'copies')
                        copies = msg.meta.copies;
                    end

                    if copies > 1
                        % Spray: give half copies to dst
                        nToGive = floor(copies / 2);
                        nKeep = copies - nToGive;

                        % Update src copy
                        msg.meta.copies = nKeep;
                        src.messages(msgId) = msg;

                        % Create dst copy
                        newMsg = msg;
                        newMsg.meta.copies = nToGive;
                        newMsg.hops = newMsg.hops + 1;
                        newMsg.bytesTransmitted = newMsg.bytesTransmitted + newMsg.sizeB;
                        newMsg.path = [newMsg.path dst.id];

                        % Check capacity
                        if dst.storage_used_bytes + newMsg.sizeB <= dst.capacity_bytes
                            dst.addMessage(newMsg);
                            sim.logTransfer(msg, src, dst, t);
                            % fprintf('Sprayed msg %d from %s to %s (copies: %d->%d,%d)\n', msg.id, src.name, dst.name, copies, nKeep, nToGive);
                        end
                    end
                end
            end
        end
    end
end
