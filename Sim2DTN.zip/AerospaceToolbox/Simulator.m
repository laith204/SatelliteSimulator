classdef Simulator < handle
    % Core simulation loop, holds nodes, messages, and executes routing.
    properties
        nodes cell = {}
        nextId (1,1) double = 1
        t (1,1) double = 0
        dt (1,1) double = 1 % seconds per tick
        speedFactor (1,1) double = 1 % Real-time multiplier
        routing % strategy object with onContact(sim,a,b,t)
        history struct
        c % constants
        logBuffer cell = {} % Store logs for UI
        activeContacts double = [] % Nx2 matrix of node IDs
        lastContacts double = [] % Previous step contacts
    end
    methods
        function self = Simulator()
            self.c.Re_km = 6371;
            self.history = struct('deliveries',[], 'transfers', []);
            self.setRouting('SprayAndWait');
        end
        function setRouting(self, name)
            switch lower(string(name))
                case "spray and wait"
                    self.routing = routing.SprayAndWait(4);
                case "prophet"
                    self.routing = routing.Prophet();
                case "cgr-lite"
                    self.routing = routing.CGRLite();
                otherwise
                    self.routing = routing.SprayAndWait(4);
            end
        end
        function id = addLEO(self, name, alt, inc, raan)
            n = dtn.LEO(self.nextId, name, alt, inc, raan); self.nodes{end+1}=n; id=self.bump();
        end
        function id = addMEO(self, name, alt, inc, raan)
            n = dtn.MEO(self.nextId, name, alt, inc, raan); self.nodes{end+1}=n; id=self.bump();
        end
        function id = addGEO(self, name, alt, raan)
            n = dtn.GEO(self.nextId, name, alt, raan); self.nodes{end+1}=n; id=self.bump();
        end
        function id = addGround(self, name, lat, lon)
            n = dtn.GroundNode(self.nextId, name, lat, lon); self.nodes{end+1}=n; id=self.bump();
        end
        function id = bump(self), self.nextId = self.nextId+1; id=self.nextId-1; end
        function node = getNodeById(self, id)
            node = [];
            for i=1:numel(self.nodes)
                if self.nodes{i}.id==id, node=self.nodes{i}; return; end
            end
        end
        function step(self)
            % advance dynamics
            dt_eff = self.dt * self.speedFactor;
            for i=1:numel(self.nodes)
                self.nodes{i}.step(dt_eff);
            end
            % check contacts and run routing
            self.handleContacts();
            self.t = self.t + dt_eff;
            if isa(self.routing, 'routing.Prophet'), self.routing.decay(); end
        end
        function handleContacts(self)
            self.activeContacts = [];
            N=numel(self.nodes);

            % Identify current contacts
            currentContacts = [];
            for i=1:N-1
                for j=i+1:N
                    a=self.nodes{i}; b=self.nodes{j};

                    % Layer Constraint Check - REMOVED to allow Ground -> GEO direct links
                    % layerA = self.getLayer(a);
                    % layerB = self.getLayer(b);
                    % if abs(layerA - layerB) > 1
                    %    continue;
                    % end

                    if self.inRange(a,b)
                        if self.lineOfSight(a,b)
                            currentContacts(end+1,:) = [a.id, b.id];
                            self.routing.onContact(self,a,b,self.t);
                        else
                            % fprintf('  -> Failed LOS\n');
                        end
                    else
                        % fprintf('  -> Failed Range\n');
                    end
                end
            end
            self.activeContacts = currentContacts;

            % Detect NEW contacts for Discovery stat
            % Simple approach: Check if pair [u,v] was in lastContacts
            % Since IDs are sorted (i<j), [u,v] is unique representation

            % Detect NEW contacts for Discovery stat
            if isempty(self.lastContacts)
                newContacts = currentContacts;
            else
                if isempty(currentContacts)
                    newContacts = [];
                else
                    newContacts = setdiff(currentContacts, self.lastContacts, 'rows');
                end
            end

            for k=1:size(newContacts, 1)
                uId = newContacts(k,1);
                vId = newContacts(k,2);
                u = self.getNodeById(uId);
                v = self.getNodeById(vId);
                u.contact_count = u.contact_count + 1;
                v.contact_count = v.contact_count + 1;
                self.logEvent('Handshake', sprintf('%s <-> %s', u.name, v.name));

                % Record for visualization (start time)
                % We need to know when it ends to draw a line segment in time?
                % Or just draw it for the duration?
                % For now, let's just log the 'contact' event with time.
                % SimEngine can infer duration or just draw instantaneous?
                % Better: Store [u, v, t_start, t_end]
                % But we only detect start here.
                % Let's just store "Contact Points" for now or rely on the viewer to interpolate?
                % Viewer 'access' object handles intervals automatically if we add them.
                % We need to track *intervals*.
            end

            % Update active contact intervals
            % This is complex to do inside the loop efficiently.
            % Alternative: Just draw lines for *transfers* (solid) and *potential* (dotted).
            % If the user wants to see "range", that's the 'access' computed by satelliteScenario.
            % satelliteScenario *automatically* computes access if we add access objects!
            % We don't need to manually draw lines if we define 'access' between all nodes.
            % BUT, we want to distinguish "Range" (dotted) vs "Transfer" (solid).
            % So, we should add access objects for ALL pairs (dotted), and then overlay solid lines for transfers.

            self.lastContacts = currentContacts;
        end

        function logEvent(self, type, details)
            % Log a structured event
            evt = struct('Time', self.t, 'Type', string(type), 'Details', string(details));
            if isfield(self.history, 'events')
                self.history.events = [self.history.events; evt];
            else
                self.history.events = evt;
            end
            % Also print to console for immediate feedback
            % fprintf('[%.1f] %s: %s\n', self.t, type, details);
        end
        function tf = inRange(~, a, b)
            d = norm(a.pos_ecef - b.pos_ecef);
            % Use max range to allow asymmetric links (e.g. GEO -> LEO)
            tf = (d <= max(a.range_km, b.range_km));
        end
        function tf = lineOfSight(self, a, b)
            % Simple horizon check: midpoint must be outside Earth sphere (no obstruction).
            Re = self.c.Re_km;
            p = a.pos_ecef; q = b.pos_ecef;
            v = q - p; t = dot(-p, v)/dot(v,v);
            t = max(0,min(1,t));
            closest = p + t*v;
            tf = norm(closest) >= Re - 0.1; % path passes above Earth's surface (with tolerance)
        end
        function msg = createMessage(self, srcId, dstId, sizeBytes, packetSizeBytes)
            if nargin<4, sizeBytes = 1000; end
            if nargin<5, packetSizeBytes = 1000; end

            % Generate Friendly Name
            src = self.getNodeById(srcId);
            msgName = sprintf('%s MSG %d', src.name, src.created_count + 1);

            msg = struct('id', randi(1e8), 'name', msgName, 'src', srcId, 'dst', dstId, ...
                'sizeB', sizeBytes, 'packetSizeB', packetSizeBytes, ...
                't0', self.t, ...
                'hops', 0, 'bytesTransmitted', 0, ...
                'path', [srcId], ...
                'meta', struct('color', rand(1,3)));

            % give it to source
            if ismethod(self.routing, 'initMessage'), msg = self.routing.initMessage(msg); end

            src.created_count = src.created_count + 1;
            src.addMessage(msg);
            self.logEvent('Created', sprintf('%s (%s -> %s)', msg.name, src.name, self.getNodeById(dstId).name));
        end

        function deliverIfArrived(self, msg, node, tnow)
            if node.id==msg.dst
                % throughput (B/s) and latency (s)
                latency = tnow - msg.t0;
                thr = msg.sizeB / max(1e-3, latency);

                % Overhead: (Total Bytes - Msg Size) / Msg Size
                overhead = 0;
                if isfield(msg, 'bytesTransmitted')
                    overhead = max(0, (msg.bytesTransmitted - msg.sizeB) / msg.sizeB);
                end

                self.history.deliveries = [self.history.deliveries; struct('msg',msg,'latency',latency,'throughput',thr)];

                self.logEvent('Delivered', sprintf('%s to %s (Lat: %.1fs)', msg.name, node.name, latency));

                % cleanup copies
                for k=1:numel(self.nodes)
                    self.nodes{k}.removeMessage(msg.id);
                end
            end
        end

        function logTransfer(self, msg, src, dst, t)
            % Record a successful transfer for visualization
            self.history.transfers = [self.history.transfers; struct('msgId', msg.id, 'color', msg.meta.color, 'src', src.id, 'dst', dst.id, 'time', t)];
            self.logEvent('Custody', sprintf('%s: %s -> %s', msg.name, src.name, dst.name));
        end

        function stats = getStats(self)
            % Collect stats for GUI
            stats = struct();

            % Overall
            nCreated = 0;
            nDelivered = numel(self.history.deliveries);

            % Node Stats
            stats.nodes = [];
            for i=1:numel(self.nodes)
                n = self.nodes{i};
                nCreated = nCreated + n.created_count; % Assuming nodes track this

                s = struct();
                s.Name = n.name;
                s.Dropped_Bytes = n.dropped_bytes;
                s.Dropped_Pkts = n.dropped_count;
                s.Buffer_Used = n.storage_used_bytes;
                s.Custody = n.messages.Count; % Current messages held
                s.Discovery = n.contact_count;
                s.Dupes = 0; % Not actively tracked per node yet
                s.Errors = 0;

                if isempty(stats.nodes)
                    stats.nodes = s;
                else
                    stats.nodes(end+1) = s;
                end
            end

            stats.total_created = nCreated;
            stats.total_delivered = nDelivered;
            stats.pdr = 0;
            if nCreated > 0, stats.pdr = (nDelivered/nCreated)*100; end

            % Deliveries analysis
            totalLat = 0;
            totalThr = 0;
            if nDelivered > 0
                for k=1:nDelivered
                    d = self.history.deliveries(k);
                    totalLat = totalLat + d.latency;
                    totalThr = totalThr + d.throughput;
                end
                stats.avg_latency = totalLat / nDelivered;
                stats.avg_throughput = totalThr / nDelivered;
            else
                stats.avg_latency = 0;
                stats.avg_throughput = 0;
            end

            stats.total_dropped_B = 0; % Aggregate from nodes if needed
            stats.total_dropped_P = 0;

            stats.routing_algo = class(self.routing);
            stats.events = self.history.events;
        end
        function layer = getLayer(~, node)
            switch node.kind
                case "Ground"
                    layer = 0;
                case "LEO"
                    layer = 1;
                case "MEO"
                    layer = 2;
                case "GEO"
                    layer = 3;
                otherwise
                    layer = -1; % Unknown
            end
        end
    end
end
