classdef SetupGUI < handle
    properties
        Fig
        Grid

        % Data
        Nodes = {}
        Messages = {}

        % UI Elements
        RoutingDropDown
        NodeList
        MessageList

        % Node Inputs
        NodeTypeDropDown
        NodeNameEdit
        BufferSizeEdit
        BandwidthEdit

        % Message Inputs
        MsgSrcDropDown
        MsgDstDropDown
        MsgSizeEdit
        MsgPktSizeEdit

        % Global Inputs
        DurationEdit
        RangeEdit
    end

    methods
        function self = SetupGUI()
            self.createUI();
        end

        function createUI(self)
            % Larger window for better readability
            self.Fig = uifigure('Name', 'DTN Simulation Setup (Aerospace)', 'Position', [100 100 1100 800]);
            self.Grid = uigridlayout(self.Fig, [4, 2]);
            self.Grid.RowHeight = {100, '1x', 280, 80}; % Increased heights, flexible middle
            self.Grid.ColumnWidth = {'1x', '1x'};
            self.Grid.RowSpacing = 15;
            self.Grid.ColumnSpacing = 15;
            self.Grid.Padding = [20 20 20 20];

            % --- Row 1: Global Settings ---
            pnlGlobal = uipanel(self.Grid, 'Title', 'Global Settings', 'FontSize', 11, 'FontWeight', 'bold');
            pnlGlobal.Layout.Row = 1;
            pnlGlobal.Layout.Column = [1 2];
            glGlobal = uigridlayout(pnlGlobal, [1, 2]);
            glGlobal.ColumnWidth = {200, '1x'};
            glGlobal.Padding = [15 15 15 15];
            glGlobal.RowSpacing = 10;
            glGlobal.ColumnSpacing = 15;
            uilabel(glGlobal, 'Text', 'Routing Algorithm:', 'FontWeight', 'bold', 'FontSize', 13);
            self.RoutingDropDown = uidropdown(glGlobal, 'Items', {'Spray and Wait', 'Prophet', 'CGR-Lite'}, 'FontSize', 12);

            uilabel(glGlobal, 'Text', 'Duration (Hours):', 'FontWeight', 'bold', 'FontSize', 13);
            self.DurationEdit = uieditfield(glGlobal, 'numeric', 'Value', 24, 'FontSize', 12);

            % --- Row 2 (Left): Node List ---
            pnlNodeList = uipanel(self.Grid, 'Title', 'Nodes', 'FontSize', 11, 'FontWeight', 'bold');
            pnlNodeList.Layout.Row = 2;
            pnlNodeList.Layout.Column = 1;
            glNodeList = uigridlayout(pnlNodeList, [1, 1]);
            glNodeList.Padding = [5 5 5 5];
            self.NodeList = uilistbox(glNodeList);
            self.NodeList.Items = {};

            % --- Row 3 (Left): Add Node Controls ---
            pnlNode = uipanel(self.Grid, 'Title', 'Add Node', 'FontSize', 11, 'FontWeight', 'bold');
            pnlNode.Layout.Row = 3;
            pnlNode.Layout.Column = 1;
            glNode = uigridlayout(pnlNode, [6, 2]);
            glNode.RowHeight = {32, 32, 32, 32, 32, 40};
            glNode.ColumnWidth = {140, '1x'};
            glNode.Padding = [10 10 10 10];
            glNode.RowSpacing = 5;
            glNode.ColumnSpacing = 10;

            uilabel(glNode, 'Text', 'Type:', 'FontWeight', 'bold', 'FontSize', 11);
            self.NodeTypeDropDown = uidropdown(glNode, 'Items', {'LEO', 'MEO', 'GEO', 'Ground'}, ...
                'FontSize', 11, 'ValueChangedFcn', @self.onTypeChanged);

            uilabel(glNode, 'Text', 'Name:', 'FontWeight', 'bold', 'FontSize', 11);
            self.NodeNameEdit = uieditfield(glNode, 'text', 'Value', 'LEO 1', 'FontSize', 11);

            uilabel(glNode, 'Text', 'Buffer (MB):', 'FontWeight', 'bold', 'FontSize', 11);
            self.BufferSizeEdit = uieditfield(glNode, 'numeric', 'Value', 100, 'FontSize', 11);

            uilabel(glNode, 'Text', 'Bandwidth (Mbps):', 'FontWeight', 'bold', 'FontSize', 11);
            self.BandwidthEdit = uieditfield(glNode, 'numeric', 'Value', 10, 'FontSize', 11);

            uilabel(glNode, 'Text', 'Range (km):', 'FontWeight', 'bold', 'FontSize', 11);
            self.RangeEdit = uieditfield(glNode, 'numeric', 'Value', 7500, 'FontSize', 11); % Increased Default

            btnAddNode = uibutton(glNode, 'Text', 'Add Node', 'ButtonPushedFcn', @self.onAddNode, 'FontSize', 11);
            btnAddNode.Layout.Column = [1 2];

            % --- Row 2 (Right): Message List ---
            pnlMsgList = uipanel(self.Grid, 'Title', 'Messages', 'FontSize', 11, 'FontWeight', 'bold');
            pnlMsgList.Layout.Row = 2;
            pnlMsgList.Layout.Column = 2;
            glMsgList = uigridlayout(pnlMsgList, [1, 1]);
            glMsgList.Padding = [5 5 5 5];
            self.MessageList = uilistbox(glMsgList);
            self.MessageList.Items = {};

            % --- Row 3 (Right): Add Message Controls ---
            pnlMsg = uipanel(self.Grid, 'Title', 'Add Message', 'FontSize', 11, 'FontWeight', 'bold');
            pnlMsg.Layout.Row = 3;
            pnlMsg.Layout.Column = 2;
            glMsg = uigridlayout(pnlMsg, [5, 2]);
            glMsg.RowHeight = {32, 32, 32, 32, 40};
            glMsg.ColumnWidth = {140, '1x'};
            glMsg.Padding = [10 10 10 10];
            glMsg.RowSpacing = 5;
            glMsg.ColumnSpacing = 10;

            uilabel(glMsg, 'Text', 'Source:', 'FontWeight', 'bold', 'FontSize', 11);
            self.MsgSrcDropDown = uidropdown(glMsg, 'Items', {}, 'FontSize', 11);

            uilabel(glMsg, 'Text', 'Destination:', 'FontWeight', 'bold', 'FontSize', 11);
            self.MsgDstDropDown = uidropdown(glMsg, 'Items', {}, 'FontSize', 11);

            uilabel(glMsg, 'Text', 'Size (KB):', 'FontWeight', 'bold', 'FontSize', 11);
            self.MsgSizeEdit = uieditfield(glMsg, 'numeric', 'Value', 1000, 'FontSize', 11);

            uilabel(glMsg, 'Text', 'Packet Size (KB):', 'FontWeight', 'bold', 'FontSize', 11);
            self.MsgPktSizeEdit = uieditfield(glMsg, 'numeric', 'Value', 1, 'FontSize', 11);

            btnAddMsg = uibutton(glMsg, 'Text', 'Add Message', 'ButtonPushedFcn', @self.onAddMessage, 'FontSize', 11);
            btnAddMsg.Layout.Column = [1 2];

            % --- Row 4: Start Button ---
            btnStart = uibutton(self.Grid, 'Text', 'Start Simulation', ...
                'BackgroundColor', [0.2 0.8 0.2], ...
                'FontSize', 16, ...
                'FontWeight', 'bold', ...
                'ButtonPushedFcn', @self.onStartSim);
            btnStart.Layout.Row = 4;
            btnStart.Layout.Column = [1 2];
        end

        function onTypeChanged(self, src, ~)
            switch src.Value
                case 'LEO'
                    self.RangeEdit.Value = 7500;
                case 'MEO'
                    self.RangeEdit.Value = 25000;
                case 'GEO'
                    self.RangeEdit.Value = 50000;
                case 'Ground'
                    self.RangeEdit.Value = 7500;
            end
            % Update name suggestion
            self.NodeNameEdit.Value = self.getNextName(src.Value);
        end

        function onAddNode(self, ~, ~)
            type = self.NodeTypeDropDown.Value;
            name = self.NodeNameEdit.Value;
            buf = self.BufferSizeEdit.Value;
            bw = self.BandwidthEdit.Value;
            rngKm = self.RangeEdit.Value;

            % Randomize parameters based on type
            % (Logic will be handled in SimEngine, here we just store config)
            nodeConfig = struct('type', type, 'name', name, 'buffer', buf, 'bandwidth', bw, 'range', rngKm);
            self.Nodes{end+1} = nodeConfig;

            self.updateLists();

            % Auto-increment name for the CURRENT type (ready for next add)
            self.NodeNameEdit.Value = self.getNextName(type);
        end

        function name = getNextName(self, type)
            count = 0;
            for i = 1:numel(self.Nodes)
                if strcmp(self.Nodes{i}.type, type)
                    count = count + 1;
                end
            end

            if strcmp(type, 'Ground')
                prefix = 'Ground Node';
            else
                prefix = type;
            end
            name = sprintf('%s %d', prefix, count + 1);
        end

        function onAddMessage(self, ~, ~)
            srcName = self.MsgSrcDropDown.Value;
            dstName = self.MsgDstDropDown.Value;

            if isempty(srcName) || isempty(dstName) || strcmp(srcName, dstName)
                uialert(self.Fig, 'Invalid Source/Dest', 'Error');
                return;
            end

            sizeKB = self.MsgSizeEdit.Value;
            pktKB = self.MsgPktSizeEdit.Value;

            msgConfig = struct('src', srcName, 'dst', dstName, 'sizeKB', sizeKB, 'pktKB', pktKB);
            self.Messages{end+1} = msgConfig;

            self.updateLists();
        end

        function updateLists(self)
            % Update Node List
            nodeItems = {};
            nodeNames = {};
            for i=1:numel(self.Nodes)
                n = self.Nodes{i};
                nodeItems{end+1} = sprintf('%s (%s) [Buf: %d MB, Rng: %d km]', n.name, n.type, n.buffer, n.range);
                nodeNames{end+1} = n.name;
            end
            self.NodeList.Items = nodeItems;

            % Update Dropdowns
            self.MsgSrcDropDown.Items = nodeNames;
            self.MsgDstDropDown.Items = nodeNames;

            % Update Message List
            msgItems = {};
            for i=1:numel(self.Messages)
                m = self.Messages{i};
                msgItems{end+1} = sprintf('%s -> %s (%d KB)', m.src, m.dst, m.sizeKB);
            end
            self.MessageList.Items = msgItems;
        end

        function onStartSim(self, ~, ~)
            % Gather all config
            config.routing = self.RoutingDropDown.Value;
            config.duration = self.DurationEdit.Value;
            config.nodes = self.Nodes;
            config.messages = self.Messages;

            % Close Setup
            close(self.Fig);

            % Start Engine
            % Assuming SimEngine is in the same package or path
            import AerospaceToolbox.SimEngine.*
            engine = SimEngine(config);
            engine.run();
        end
    end
end
