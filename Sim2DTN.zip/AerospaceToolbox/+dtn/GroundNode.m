classdef GroundNode < dtn.Node
    methods
        function self = GroundNode(id,name,lat0,lon0)
            self@dtn.Node(id,name,'Ground');
            if nargin < 3
                lat0 = -60 + 120*rand();
                lon0 = -180 + 360*rand();
            end
            self.lat = lat0; self.lon = lon0; self.alt_km = 0.05;
            self.updateECEF();
        end
        function step(self, dt)
            % Call superclass to update ECEF position
            step@dtn.Node(self, dt);
        end
    end
end
