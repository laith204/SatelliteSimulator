function test_sim_engine()
% Test script for Aerospace SimEngine

% Mock Config
config.routing = 'Spray and Wait';

% Nodes
% Nodes
config.nodes = {};
config.nodes{end+1} = struct('type', 'LEO', 'name', 'LEO1', 'buffer', 100, 'bandwidth', 10, 'range', 5000);
config.nodes{end+1} = struct('type', 'GEO', 'name', 'GEO1', 'buffer', 100, 'bandwidth', 10, 'range', 50000);
config.nodes{end+1} = struct('type', 'Ground', 'name', 'Ground1', 'buffer', 1000, 'bandwidth', 100, 'range', 5000);

% Messages
config.messages = {};
config.messages{end+1} = struct('src', 'Ground1', 'dst', 'LEO1', 'sizeKB', 10, 'pktKB', 1);
config.messages{end+1} = struct('src', 'LEO1', 'dst', 'GEO1', 'sizeKB', 10, 'pktKB', 1);

% Initialize Engine
% import AerospaceToolbox.SimEngine % Not a package
engine = SimEngine(config);

% Shorten duration for test
engine.StopTime = engine.StartTime + minutes(60);
engine.SampleTime = 30; % Coarser step for speed

% Run
fprintf('Starting Test Simulation...\n');
try
    % engine.run();

    % Manual Run to skip visualize
    import dtn.*
    engine.Sim = Simulator();
    engine.Sim.setRouting(engine.Config.routing);
    engine.Sim.dt = engine.SampleTime;

    engine.Scenario = satelliteScenario(engine.StartTime, engine.StopTime, engine.SampleTime);

    engine.addNodes();
    engine.addMessages();

    fprintf('Running Logic...\n');
    engine.runLogic();

    fprintf('Test Simulation Completed Successfully.\n');

    % Check results
    stats = engine.Sim.getStats();
    fprintf('Total Created: %d\n', stats.total_created);
    fprintf('Total Delivered: %d\n', stats.total_delivered);
catch e
    fprintf('Test Simulation Failed: %s\n', e.message);
    fprintf('Stack trace:\n');
    for k=1:length(e.stack)
        fprintf('%s line %d\n', e.stack(k).file, e.stack(k).line);
    end
    rethrow(e);
end
end
